# example-user-syscall

Demonstrates how to register a handler for the "syscall from user mode" exception,
drop to the user mode privilege level, and then issue a syscall.
