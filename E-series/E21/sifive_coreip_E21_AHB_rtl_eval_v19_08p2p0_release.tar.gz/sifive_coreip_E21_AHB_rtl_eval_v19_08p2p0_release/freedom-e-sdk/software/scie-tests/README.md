# example-scie-tests
A simple example showing SCIE instructions
