# multicore-hello

An example which demonstrates how to run code on multiple CPU harts and to use
the Metal Lock API to use a spinlock as a mutex.
