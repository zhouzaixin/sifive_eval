# example-software-interrupt
A simple "Software Interrupt" example using mee-interrupts APIs for registration and setting and clearing software IPI.
