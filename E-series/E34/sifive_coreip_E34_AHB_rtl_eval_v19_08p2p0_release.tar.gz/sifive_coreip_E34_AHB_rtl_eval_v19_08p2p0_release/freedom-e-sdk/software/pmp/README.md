# example-pmp
Demonstrates how to use Freedom Metal to configure a PMP (Physical Memory
Protection) Region.
