#!/bin/sh
exec @PYTHON@ -u '@pythondir@/freedom-bin2hex.py' ${1+"$@"}
