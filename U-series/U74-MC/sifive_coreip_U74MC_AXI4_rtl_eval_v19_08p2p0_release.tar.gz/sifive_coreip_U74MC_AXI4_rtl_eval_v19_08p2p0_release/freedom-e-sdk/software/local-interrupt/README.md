# example-local-interrupt
A simple "Local Interrupt" example using metal-interrupts APIs for toggle ARTY board LEDs via buttons and switch.
